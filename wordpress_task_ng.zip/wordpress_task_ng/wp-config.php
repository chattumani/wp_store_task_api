<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'nginx_task' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'mGvKd^&)?yDo|C!LD4W;z3s&_qkw-mNp:cI=K4 ,VxyyC}!F2953+#?e%GcEdD7i' );
define( 'SECURE_AUTH_KEY',  '`UY,>RYc`w_Snp6TW|{dSzz}|SZ!G]&q8ES%sZ4]Y=uCRAHgAa:4jK?jv)ru}RH%' );
define( 'LOGGED_IN_KEY',    ']{ArE[<9l.1Oe/%]+.:_0i{od?oydvB5$f[_qw&9<@pw7~o4p^aA^]U{rNwc*tKE' );
define( 'NONCE_KEY',        'tQ8ywtN>d}F3V;Udf/:]QBA5oK@+zN;{{t?){fN7m=4;0qK*uljC{9PnDZ6=UT;I' );
define( 'AUTH_SALT',        'S^,L~[uS[T5TQ?`oN:;XR;%#T]VTX%+_Jvv9_D]L=Ts/=xG_<,f?6y6w `g&%Gpy' );
define( 'SECURE_AUTH_SALT', 'K))]X4R+1x)zW]SD3`_;9i@Y>M)%[_fAtn6u-EM}ngMe0}s$_]{IUe_ScS=x<NO4' );
define( 'LOGGED_IN_SALT',   '+lr|ka% UJzTN5HG2%[O[zeq|/*}-{;=M#rig|a$GV5#ph?1tMN^~=Ab0k(&<tyv' );
define( 'NONCE_SALT',       '4}x>z~9Ti5Ey*{h7~eu0V8ze;;U^Hki?Q3s?<,B$>_@/lV)8:^#PuIy_$Zm#Oo$M' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
